<?php
$host = "localhost";
$db = "sistemae_bddemo"; 
$user_db = "sistemae_userdemo";
$pass_db = "Kl.1hVOc4Vy]";

$conexion = mysqli_connect($host,$user_db,$pass_db,$db);

if ($conexion) {
	date_default_timezone_set("America/Lima"); 
}else{
	echo "error de conexion a la base de datos";
	
}
$conexion->set_charset("utf8");
?>